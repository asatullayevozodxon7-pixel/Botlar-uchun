p = "baklashga.py"
s = open(p, encoding="utf-8").read()

def rep(old, new):
    global s
    assert s.count(old) == 1, "TOPILMADI yoki takror: " + old[:60]
    s = s.replace(old, new, 1)

rep('''def save_price(kind: str, stars: int):''', '''EMOJIS_PER_PRICE = max(1, int(os.environ.get("EMOJIS_PER_PRICE", "2")))


def pack_total_price(kind: str, count: int) -> int:
    """Narx har EMOJIS_PER_PRICE ta emoji uchun (standart: 2 ta emoji = narx)."""
    count = max(1, count or 1)
    return -(-count // EMOJIS_PER_PRICE) * load_price(kind)


def save_price(kind: str, stars: int):''')

rep("    total_price = unit_price * count\n", "    total_price = pack_total_price(kind, count)\n")
rep('f"({unit_price} ⭐ x {count})"', 'f"(har {EMOJIS_PER_PRICE} ta emoji = {unit_price} ⭐)"')
rep("payment_choice_keyboard(unit_price * (len(paths) or 1), credits)", "payment_choice_keyboard(pack_total_price(kind, len(paths) or 1), credits)")
rep("    expected_price = load_price(kind) * count\n", "    expected_price = pack_total_price(kind, count)\n")
rep('f"({count} ta x {load_price(kind)} ⭐)"', 'f"({count} ta emoji)"')
s = s.replace("🙏❤️", "❤️").replace(" 🙏", "").replace("🙏", "")
assert "🙏" not in s

open(p, "w", encoding="utf-8").write(s)
print("TAYYOR: narx har 2 ta emoji, 🙏 olib tashlandi")
