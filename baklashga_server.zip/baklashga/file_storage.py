from __future__ import annotations
import json, os, tempfile
from typing import Any, Dict, Optional
from aiogram.fsm.state import State
from aiogram.fsm.storage.base import BaseStorage, StateType, StorageKey


class JsonFileStorage(BaseStorage):
    def __init__(self, path):
        self.path = path
        try:
            with open(path, encoding="utf-8") as f:
                self._data = json.load(f)
        except (FileNotFoundError, ValueError):
            self._data = {}

    @staticmethod
    def _k(key: StorageKey) -> str:
        return f"{key.bot_id}:{key.chat_id}:{key.user_id}:{key.thread_id}:{key.business_connection_id}:{key.destiny}"

    def _flush(self):
        d = os.path.dirname(os.path.abspath(self.path))
        fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False)
        os.replace(tmp, self.path)

    def _entry(self, key):
        return self._data.setdefault(self._k(key), {"state": None, "data": {}})

    def _cleanup(self, key):
        e = self._data.get(self._k(key))
        if e and e.get("state") is None and not e.get("data"):
            self._data.pop(self._k(key), None)

    async def set_state(self, key, state: StateType = None):
        self._entry(key)["state"] = state.state if isinstance(state, State) else state
        self._cleanup(key)
        self._flush()

    async def get_state(self, key) -> Optional[str]:
        return self._data.get(self._k(key), {}).get("state")

    async def set_data(self, key, data: Dict[str, Any]):
        self._entry(key)["data"] = json.loads(json.dumps(data))
        self._cleanup(key)
        self._flush()

    async def get_data(self, key) -> Dict[str, Any]:
        return dict(self._data.get(self._k(key), {}).get("data", {}))

    async def close(self):
        self._flush()
