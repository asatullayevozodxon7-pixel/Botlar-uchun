import re
p = "baklashga.py"
s = open(p, encoding="utf-8").read()

def rep(old, new):
    global s
    assert old in s, "TOPILMADI: " + old[:50]
    s = s.replace(old, new, 1)

rep('BOT_TOKEN = os.environ.get("BOT_TOKEN", "")\nMAX_LEN = 12', '''def _load_dotenv():
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.exists(env_path):
        return
    with open(env_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_dotenv()

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
MAX_LEN = 12''')

m = re.search(r'ADMIN_ID = 6745248562  # <--[^\n]*\nLOG_CHAT_ID = "@emojiabu"', s)
assert m, "ADMIN_ID qatori topilmadi"
s = s[:m.start()] + '''ADMIN_ID = int(os.environ.get("ADMIN_ID", "0"))
_log_chat = os.environ.get("LOG_CHAT_ID", "").strip()
LOG_CHAT_ID = int(_log_chat) if _log_chat.lstrip("-").isdigit() else (_log_chat or ADMIN_ID)''' + s[m.end():]

rep('DEFAULT_SUPPORT_CONTACT = "@cyberabu"', 'DEFAULT_SUPPORT_CONTACT = os.environ.get("SUPPORT_CONTACT", "@your_username")')

rep('"sonnet.lock", "bot.log",\n}', '"sonnet.lock", "bot.log",\n    ".env", "fsm_state.json", "promos.json", "run.log", "run.sh", "patch.py",\n}')

rep('''    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable is not set")
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher(storage=MemoryStorage())''', '''    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN o'rnatilmagan (.env faylga yozing)")
    if not ADMIN_ID:
        raise RuntimeError("ADMIN_ID o'rnatilmagan (.env faylga yozing)")
    from file_storage import JsonFileStorage
    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher(storage=JsonFileStorage(os.path.join(os.path.dirname(os.path.abspath(__file__)), "fsm_state.json")))''')

open(p, "w", encoding="utf-8").write(s)
print("TAYYOR: baklashga.py tuzatildi")
