#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")"
termux-wake-lock
while true; do
  python -B baklashga.py >> run.log 2>&1
  echo "[$(date '+%F %T')] Bot to'xtadi, 5 soniyadan so'ng qayta ishga tushadi" >> run.log
  sleep 5
done
