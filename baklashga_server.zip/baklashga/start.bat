@echo off
chcp 65001 >nul
title EMOJIABU - CS2 - 16 NAME EMOJIS
cd /d "%~dp0"
echo ========================================
echo          EMOJIABU CS2 - 16 NAME EMOJIS
echo ========================================
echo.
where py >nul 2>&1
if errorlevel 1 (
    echo XATO: Python topilmadi.
    echo Python o'rnatilganini tekshiring.
    pause
    exit /b 1
)
echo [1/2] Kutubxonalar tekshirilmoqda...
py -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo KUTUBXONA O'RNATISHDA XATO!
    pause
    exit /b 1
)
echo.
echo [2/2] Bot ishga tushmoqda...
echo Terminalni yopmang.
echo.
py -c "from templates_config import TEMPLATE_ORDER, TEMPLATES; assert len(TEMPLATE_ORDER) == 16 and TEMPLATE_ORDER[15] == 'cs2' and TEMPLATES['cs2']['label'] == 'CS 2'; print('OK: Name Emojis - 16. CS 2')"
if errorlevel 1 (
    echo XATO: CS2 fayllari mos emas. ZIPni yangi papkaga to'liq oching.
    pause
    exit /b 1
)
py -B baklashga.py
echo.
echo Bot to'xtadi.
pause
